# BlackenedMod
Blackened Mod is a kernel modification script that specifically modifies the Pixel(XL) and the Pixel 2(XL) devices for greater stability and better battery life. Works best with stock and KingKernel

## Compatibility
* Pixel(XL)/Pixel 2(XL) devices

## Change Log
(Coming soon)

## Source Code
* Module [GitHub](https://github.com/King-Kernel/blackened-mod)
